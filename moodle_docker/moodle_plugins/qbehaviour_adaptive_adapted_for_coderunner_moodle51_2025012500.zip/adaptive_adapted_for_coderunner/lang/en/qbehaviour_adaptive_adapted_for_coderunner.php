<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'qbehaviour_interactive_adapted_for_coderunner', language 'en'.
 *
 * @package    qbehaviour
 * @subpackage interactive
 * @copyright  2009 The Open University/2011-2016 Richard Lobb
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['giveup'] = 'Stop and read final feedback';
$string['notcomplete'] = 'Not complete';
$string['pluginname'] = 'Adaptive adapted for coderunner';
$string['precheck'] = 'Precheck';
$string['precheckedresponse'] = 'Prechecked: {$a}';
$string['precheckresults'] = 'Precheck results';
$string['privacy:metadata'] = 'The qbehaviour_adaptive_adapted_for_coderunner question behaviour plugin does not store any personal data.';
$string['triesremaining'] = 'Tries remaining: {$a}';
$string['tryagain'] = 'Try again';
